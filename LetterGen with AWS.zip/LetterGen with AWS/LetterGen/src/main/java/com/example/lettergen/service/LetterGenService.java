package com.example.lettergen.service;

import com.example.lettergen.domain.PolicyDetails;

import java.util.List;

public interface LetterGenService 
{

	void generatePDF(String policyNo);
}