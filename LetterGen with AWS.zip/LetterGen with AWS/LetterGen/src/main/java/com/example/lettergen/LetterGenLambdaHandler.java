package com.example.lettergen;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.example.lettergen.service.LetterGenService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class LetterGenLambdaHandler implements RequestHandler<String, String> {

    private final LetterGenService letterGenService;
    private static final ApplicationContext applicationContext;

    static {
        // Initialize Spring context once as a static variable
        applicationContext = new AnnotationConfigApplicationContext(ApplicationConfig.class);
    }

    public LetterGenLambdaHandler() {
        // Retrieve the required beans from the Spring context
        letterGenService = applicationContext.getBean(LetterGenService.class);
    }

    @Override
    public String handleRequest(String policyNumber, Context context) {
        // Print the policy number received as input
        System.out.println("Received policy number: " + policyNumber);

        try {
            // Perform logic based on the input or event triggering the Lambda function
            letterGenService.generatePDF(policyNumber);
            return "PDF generated successfully";
        } catch (Exception e) {
            e.printStackTrace();
            return "Failed to generate PDF";
        }
    }
}
