package com.example.lettergen.controller;

import com.example.lettergen.service.LetterGenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class LetterGenController {

    @Autowired
    private LetterGenService letterGenService;

    @RequestMapping(value = "/generatePDF", params = "policyNo")
    public ResponseEntity<String> generatePDF(@RequestParam("policyNo") String policyNo) {
        try {
            letterGenService.generatePDF(policyNo);
            return ResponseEntity.ok("PDF generated successfully");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to generate PDF");
        }
    }
}
