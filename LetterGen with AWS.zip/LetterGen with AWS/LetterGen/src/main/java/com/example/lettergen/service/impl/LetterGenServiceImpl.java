package com.example.lettergen.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.lettergen.domain.PolicyDetails;

import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.QueryRequest;
import software.amazon.awssdk.services.dynamodb.model.QueryResponse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.example.lettergen.repository.PolicyDetailsRepository;
import com.example.lettergen.service.LetterGenService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;

@Service
public class LetterGenServiceImpl implements LetterGenService 
{
    @Value("${output.folder.path}")
    private String outputPath;

    private final PolicyDetailsRepository policyDetailsRepository1;
    private final S3Client s3Client;
	private final DynamoDbClient dynamoDbClient;

    
	public void generatePDF(String policyNo) {
		String html = parseThymeleafTemplate(policyNo);
		try{
			generatePdfFromHtml(policyNo, html);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Autowired
	public LetterGenServiceImpl(PolicyDetailsRepository policyDetailsRepository, DynamoDbClient dynamoDbClient, S3Client s3Client) {
	    this.policyDetailsRepository1 = policyDetailsRepository; // Update this line
	    this.s3Client = s3Client;
	    this.dynamoDbClient = dynamoDbClient;
	}

	public void generatePdfFromHtml(String policyNo, String html) {
	    ITextRenderer renderer = new ITextRenderer();
	    renderer.setDocumentFromString(html);
	    renderer.layout();

	    long unixTime = System.currentTimeMillis();
	    String outputFileName = outputPath + policyNo + "_" + unixTime + ".pdf";

	    uploadPdfToS3(policyNo, outputFileName);
	    
	} 
	
	private String parseThymeleafTemplate(String policyNo) {
		
		List<Map<String, AttributeValue>> policyDetailsList = policyDetailsRepository1.findByPolicyNo(policyNo);
		
		 if (policyDetailsList != null && !policyDetailsList.isEmpty()) 
		 {		
		      
			 PolicyDetails policyDetails = (PolicyDetails) policyDetailsList.get(0);
		        String name = policyDetails.getFirstName() + " " + policyDetails.getLastName();


		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		String dateStr = formatter.format(date);

		ClassLoaderTemplateResolver templateResolver = new ClassLoaderTemplateResolver();
		templateResolver.setPrefix("/templates/");
		templateResolver.setSuffix(".html");
		
		templateResolver.setTemplateMode(TemplateMode.HTML);

		TemplateEngine templateEngine = new TemplateEngine();
		templateEngine.setTemplateResolver(templateResolver);
		Context context = new Context();
		context.setVariable("LetterDate", dateStr);
		context.setVariable("NAME", name);
		context.setVariable("ADDRESS1", policyDetails.getAddress1());
		context.setVariable("ADDRESS2", policyDetails.getAddress2());
		context.setVariable("ADDRESS3", policyDetails.getAddress3());
		context.setVariable("TITLE", "Renewal Letter");
		context.setVariable("PolicyNo", policyNo);
		context.setVariable("MainPlanName", policyDetails.getPlan());		
		context.setVariable("FREETEXT", "We refer to our Renewal Invitation letter requesting for your premium payment.");
		context.setVariable("FREETEXT1", "As we have not heard from you regarding this, we are unable to continue the insurance coverage and your\r\n" + 
				"		policy has been terminated as at 01 Mar 2020.");
				context.setVariable("FREETEXT2", "If you have any questions, please contact our customer service officers at 6332 1133 or email us at\r\n" + 
						"		healthcare@income.com.sg. We would be most happy to help you.");
				String html = templateEngine.process("LetterTemplate", context);
				
				return html;
		 }
		 
		 else {
		        return "Default HTML content"; // or throw new IllegalStateException("No policy details found for the given policy number");
		    }
		 }

	public List<PolicyDetails> findByPolicyNo(String policyNo) {
	    Map<String, AttributeValue> expressionAttributeValues = new HashMap<>();
	    expressionAttributeValues.put(":val", AttributeValue.builder().s(policyNo).build());

	    QueryRequest queryRequest = QueryRequest.builder()
	            .tableName("Customer") // Replace with your DynamoDB table name
	            .keyConditionExpression("policyno = :val") // Check if 'policyNo' is the correct primary key
	            .expressionAttributeValues(expressionAttributeValues)
	            .build();

	    QueryResponse response = dynamoDbClient.query(queryRequest);
	    List<Map<String, AttributeValue>> items = response.items();

	    return items.stream()
	            .map(this::mapToPolicyDetails)
	            .collect(Collectors.toList());
	}
	
	 private void uploadPdfToS3(String policyNo, String outputFileName) {
	        try {
	            File file = new File(outputFileName);
	            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
	                    .bucket("lettergen123") // Replace with your S3 bucket name
	                    .key(policyNo + "_" + System.currentTimeMillis() + ".pdf")
	                    .build();

	            PutObjectResponse response = s3Client.putObject(putObjectRequest, RequestBody.fromFile(file));
	            System.out.println("File uploaded to S3: " + response);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	 
	 private PolicyDetails mapToPolicyDetails(Map<String, AttributeValue> itemAttributes) 
	 {
		    PolicyDetails policyDetails = new PolicyDetails();
		    policyDetails.setPolicyNo(itemAttributes.get("policy_no").s());
		    policyDetails.setFirstName(itemAttributes.get("first_name").s());
		    policyDetails.setLastName(itemAttributes.get("last_name").s());
		    policyDetails.setAge(Integer.parseInt(itemAttributes.get("age").n())); // Assuming age is stored as a number in DynamoDB
		    policyDetails.setEmail(itemAttributes.get("email").s());
		    policyDetails.setAddress1(itemAttributes.get("address1").s());
		    policyDetails.setAddress2(itemAttributes.get("address2").s());
		    policyDetails.setAddress3(itemAttributes.get("address3").s());
		    policyDetails.setPlan(itemAttributes.get("plan").s());
		    
		    return policyDetails;
		}

	
}
