package com.example.lettergen;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.lettergen.repository.PolicyDetailsRepository;
import com.example.lettergen.service.LetterGenService;
import com.example.lettergen.service.impl.LetterGenServiceImpl;

import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.s3.S3Client;

import software.amazon.awssdk.regions.Region;

@Configuration
public class ApplicationConfig {
	
	@Bean
    public DynamoDbClient dynamoDbClient() {
        return DynamoDbClient.builder().build();
    }

	@Bean
	public PolicyDetailsRepository policyDetailsRepository(DynamoDbClient dynamoDbClient) {
	    return new PolicyDetailsRepository(dynamoDbClient);
	}

    @Bean
    public LetterGenService letterGenService(PolicyDetailsRepository policyDetailsRepository, DynamoDbClient dynamoDbClient, S3Client s3Client) {
        return new LetterGenServiceImpl(policyDetailsRepository, dynamoDbClient, s3Client);
    }


    @Bean
    public S3Client s3Client() {
        return S3Client.builder()
                .region(Region.AP_SOUTHEAST_1)
                .build();
    }
}
