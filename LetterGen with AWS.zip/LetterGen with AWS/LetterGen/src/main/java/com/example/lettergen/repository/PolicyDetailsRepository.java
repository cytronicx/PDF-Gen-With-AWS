package com.example.lettergen.repository;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.QueryRequest;
import software.amazon.awssdk.services.dynamodb.model.QueryResponse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class PolicyDetailsRepository {

    private final DynamoDbClient dynamoDbClient;

    @Autowired
    public PolicyDetailsRepository(DynamoDbClient dynamoDbClient) {
        this.dynamoDbClient = dynamoDbClient;
    }

	public List<Map<String, AttributeValue>> findByPolicyNo(String policyNo) {
		return null;
	}
}

